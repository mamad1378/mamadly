<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="/css/signup.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('signup_title'); ?></title>
</head>
<body>
    <div class="container-fluid bg-danger">
        <div class="d-flex flex-wrap align-content-center mx-auto p-3 bg-success">
            <?php echo $__env->yieldContent('form'); ?>
        </div>
    </div>
</body>
</html><?php /**PATH F:\feedly\resources\views/signup/signuplayout.blade.php ENDPATH**/ ?>