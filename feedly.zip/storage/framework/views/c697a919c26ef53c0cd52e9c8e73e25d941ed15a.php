<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" type="text/css" href="/css/bootstrap/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="/css/signup.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('signupTitle'); ?></title>
</head>
<body>
    <div class="container-fluid bg-danger">
        <div class="d-flex flex-wrap align-content-center mx-auto p-3 bg-success">
            <?php echo $__env->yieldContent('form'); ?>
        </div>
    </div>
    <script src="/css/bootstrap/popper.min.js"></script>
    <script src="/css/bootstrap/jquery-3.5.1.slim.min.js"></script>
    <script src="/css/bootstrap/bootstrap.min.js"></script>
</body>
</html><?php /**PATH F:\feedly\resources\views/signup/signupLayout.blade.php ENDPATH**/ ?>